function love.conf(t)
	t.title = "Seance Game"
	t.author = "Vapor"
	t.version = "0.10.0"

	t.window.width = 800
	t.window.height = 800 
	t.window.resizable = false
  	t.console = true
end
