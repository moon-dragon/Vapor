local frankenstein = {}
frankenstein.animation = {}

frankenstein.speed = 4 -- multiplied speed by 10, to accommodate current implementation of local monster wandering
frankenstein.nemesis = {}
frankenstein.maxAgitation = 8
frankenstein.animation.idleDuration = 4
frankenstein.animation.walkingDuration = 20

return frankenstein